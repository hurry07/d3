var liste_scroll_titre_actif=0,liste_scroll_menus=false,liste_scroll_y=90;
var liste_scroll_invite=new Array("","","");
var liste_scroll_prefixe="",liste_scroll_num_window=0,liste_scroll_decale=0;
var liste_scrool_titres=new Array(),liste_scroll_appui=false,scroll_x=0,scroll_y=0;

function add_list_scroll(file,noeud,invites,options,num)
{liste_scroll_prefixe=noeud;
liste_scroll_invite=invites.split("\n");
liste_scroll_titres=options.split("\n");
liste_scroll_num_window=num;
liste_scroll_titre_actif=0;liste_scroll_menus=false;
node=svgdoc.getElementById(noeud);
getURL (file, liste_scroll_window);
}

function liste_scroll_init()
{liste_ecris_chaine();
objet=svgdoc.getElementById("liste_titre2");
child=objet.getFirstChild();
child.setData(liste_scroll_titres[liste_scroll_titre_actif])
var nb_menus=liste_scroll_titres.length;
ou=svgdoc.getElementById("scroll_textes");
for (i=0;i<nb_menus;i++)
{node=svgdoc.createElement("text");
node.setAttribute("x",10);node.setAttribute("y",15+20*i);
texte=svgdoc.createTextNode(liste_scroll_titres[i]);
node.appendChild(texte);
ou.appendChild(node)};}

function liste_scroll_window( data ) {
if (data.success) {
var doc_frag = parseXML ( data.content, svgdoc);
childs=doc_frag.getChildNodes();
nombre=childs.getLength();
for (i=0;i<nombre;i++)
{child=childs.item(i);
node.appendChild (child)};
liste_scroll_init();
} else {
alert ("Error reading file");
}}

function remove_window(noeud)
{ou=svgdoc.getElementById(noeud);
childs=ou.getChildNodes();
nombre=childs.getLength();
for (i=nombre-1;i>=0;i--)
{child=childs.item(i);
ou.removeChild (child)}
}

function liste_ecris_chaine()
{for (i=0;i<3;i++)
{objet = svgdoc.getElementById('invite'+i.toString());
child=objet.getFirstChild();
child.setData(liste_scroll_invite[i])
}
}

function list_tape(evt)
{key = evt.getCharCode();
if (key==13) {close_liste(true)};
if (key==27) {close_liste(false)};
}

function close_list_scroll(result)
{
remove_window(liste_scroll_prefixe);
eval(liste_scroll_prefixe+"_use_list_scroll(result,liste_scroll_titre_actif,liste_scroll_num_window)");
}

function liste_scroll_faire(evt)
{liste_scroll_y=evt.getClientY()-10;
if (liste_scroll_menus==false) 
{liste_scroll_menus=true;liste_scroll_affiche(evt)} 
else {liste_scroll_menus=false;liste_scroll_cache(evt)}}

function liste_scroll_affiche(evt)
{liste_scroll_decale=0;
node=svgdoc.getElementById("liste_scroll_montre");
node.setAttribute("y",0);
liste_scroll_titre_actif=0;
objet=svgdoc.getElementById("liste_scroll_inv_menu");
objet.setAttribute("y",90);
node=svgdoc.getElementById("scroll_cursor");
node.setAttribute("y",130);
node=svgdoc.getElementById("ddown_list");
node.getStyle.setProperty("display","inline");
}

function liste_scrolling(pas)
{liste_scroll_decale+=pas;
if ((liste_scroll_decale>=0)&&(liste_scroll_decale<=liste_scroll_titres.length-6))
{node=svgdoc.getElementById("liste_scroll_montre");
node.setAttribute("y",-20*liste_scroll_decale);
var y_pos=parseInt(40*liste_scroll_decale/(liste_scroll_titres.length-6));
node=svgdoc.getElementById("scroll_cursor");
node.setAttribute("y",130+y_pos);
}
else
{liste_scroll_decale-=pas}}

function liste_scroll_inverse(evt)
{ym=evt.getClientY()-1;sous_menu=Math.floor((ym-liste_scroll_y)/20);
if (sous_menu>=0)
{objet=svgdoc.getElementById("liste_scroll_inv_menu");
objet.setAttribute("y",90+20*sous_menu);
}}

function liste_scroll_cache(evt)
{node=svgdoc.getElementById("ddown_list");
node.getStyle.setProperty("display","none");
}

function liste_glisse_click(evt,valeur)
{scroll_y=evt.getClientY();
liste_scroll_appui=true}

function liste_glisse(evt)
{if (liste_scroll_appui==true)
{ym=evt.getClientY();
var decale=parseInt((ym-scroll_y)*(liste_scroll_titres.length-6)/50);
if (decale!=0)
{liste_scroll_decale+=decale;
if (liste_scroll_decale<0) {liste_scroll_decale=0};
if (liste_scroll_decale>liste_scroll_titres.length-6)
{liste_scroll_decale=liste_scroll_titres.length-6};
node=svgdoc.getElementById("liste_scroll_montre");
node.setAttribute("y",-20*liste_scroll_decale);
var y_pos=parseInt(40*liste_scroll_decale/(liste_scroll_titres.length-6));
node=svgdoc.getElementById("scroll_cursor");
node.setAttribute("y",130+y_pos);
}
}}

function liste_scroll_choix(evt)
{ym=evt.getClientY()-1;
var sous_menu=Math.floor((ym-liste_scroll_y)/20);
sous_menu=sous_menu+liste_scroll_decale;
if (sous_menu>=0)
{liste_scroll_titre_actif=sous_menu;liste_scroll_cache(evt);
objet=svgdoc.getElementById("liste_titre2");child=objet.getFirstChild();
child.setData(liste_scroll_titres[liste_scroll_titre_actif])};
liste_scroll_menus=false}
